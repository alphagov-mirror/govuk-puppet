require 'puppet_x/jenkins'

module PuppetX::Jenkins::Type; end
