module PuppetX; end
module PuppetX::Jenkins; end
